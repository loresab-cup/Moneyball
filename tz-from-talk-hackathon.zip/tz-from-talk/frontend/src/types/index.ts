export type Requirement={id:number;code:string;title:string;description:string;type:string;priority:string;role:string;status:string;source_text:string;start_time:number|null;end_time:number|null;confidence:number;needs_clarification:boolean;priority_reason:string;comment:string};
export type Segment={id:number;start_time:number;end_time:number;text:string;speaker?:string|null};
export type Project={id:number;title:string;description:string;status:string;requirements:Requirement[];segments:Segment[];tasks:any[];questions:any[];contradictions:any[];roles:string[];spec:any};
