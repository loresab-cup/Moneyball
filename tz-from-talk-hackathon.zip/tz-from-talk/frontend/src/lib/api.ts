const API='http://localhost:8000/api';
export function token(){return localStorage.getItem('tz_token')||''}
async function req(path:string,opts:RequestInit={}){const r=await fetch(API+path,{...opts,headers:{...(opts.body instanceof FormData?{}:{'Content-Type':'application/json'}),Authorization:`Bearer ${token()}`,...opts.headers}}); if(!r.ok){let e='Ошибка';try{e=(await r.json()).detail||e}catch{};throw new Error(e)}return r}
export async function register(email:string,password:string){const r=await req('/auth/register',{method:'POST',body:JSON.stringify({email,password})});return r.json()}
export async function login(email:string,password:string){const r=await req('/auth/login',{method:'POST',body:JSON.stringify({email,password})});return r.json()}
export async function projects(){return (await req('/projects')).json()}
export async function createProject(title:string,description:string){return (await req('/projects',{method:'POST',body:JSON.stringify({title,description})})).json()}
export async function project(id:number){return (await req(`/projects/${id}`)).json()}
export async function upload(id:number,file:File){const f=new FormData();f.append('file',file);return (await req(`/projects/${id}/media`,{method:'POST',body:f})).json()}
export async function process(id:number){return (await req(`/projects/${id}/process`,{method:'POST'})).json()}
export async function job(id:number){return (await req(`/projects/${id}/jobs/latest`)).json()}
export async function createRequirement(projectId:number){return (await req(`/projects/${projectId}/requirements`,{method:'POST'})).json()}
export function mediaUrl(id:number){return `${API}/projects/${id}/media`}
export async function updateRequirement(id:number,data:any){return (await req(`/requirements/${id}`,{method:'PATCH',body:JSON.stringify(data)})).json()}
export async function updateSpec(id:number,content:any){return (await req(`/projects/${id}/technical-specification`,{method:'PATCH',body:JSON.stringify({content})})).json()}
export async function history(id:number){return (await req(`/projects/${id}/history`)).json()}
