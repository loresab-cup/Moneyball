# Architecture

React/TypeScript → REST → FastAPI → Service layer → PostgreSQL.

Long operations are represented as persisted `AIProcessingJob` records. The MVP runs them in FastAPI BackgroundTasks so the HTTP request returns immediately; the worker boundary is isolated in `workers/pipeline.py`, allowing Celery/Redis later without moving business logic into React.

The core value of the case is source traceability: requirements store `RequirementSource` rows pointing to `TranscriptionSegment`, while the requirement also keeps start/end/source text for fast UI rendering.
