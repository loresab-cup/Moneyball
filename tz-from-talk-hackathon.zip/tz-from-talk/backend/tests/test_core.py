from app.core.security import hash_password, verify_password

def test_password():
    h=hash_password('secret123'); assert verify_password('secret123',h); assert not verify_password('bad',h)
