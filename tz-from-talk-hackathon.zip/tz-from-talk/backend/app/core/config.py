from pydantic_settings import BaseSettings, SettingsConfigDict

class Settings(BaseSettings):
    app_name: str = "From Talk to TZ"
    database_url: str = "sqlite:///./app.db"
    secret_key: str = "change-me-in-production"
    access_token_expire_minutes: int = 60 * 24
    frontend_url: str = "http://localhost:5173"
    stt_api_key: str = ""
    stt_api_url: str = "https://api.openai.com/v1/audio/transcriptions"
    stt_model: str = "whisper-1"
    llm_api_key: str = ""
    llm_api_url: str = "https://api.openai.com/v1/chat/completions"
    llm_model: str = "gpt-4o-mini"
    demo_mode: bool = True
    max_upload_mb: int = 100
    model_config = SettingsConfigDict(env_file=".env", extra="ignore", case_sensitive=False)

settings = Settings()
