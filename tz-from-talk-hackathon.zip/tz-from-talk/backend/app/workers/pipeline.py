from pathlib import Path
import json
from sqlalchemy.orm import Session
from app.core.db import SessionLocal
from app.models import *
from app.services.stt_service import SpeechToTextService
from app.services.ai_service import AIAnalysisService

def set_job(db, job, status, step, progress, error=""):
    job.status,status_ok = status,status
    job.step=step; job.progress=progress; job.error=error; db.commit(); db.refresh(job)

def run_pipeline(project_id: int, job_id: int):
    db = SessionLocal()
    project=db.get(Project,project_id); job=db.get(AIProcessingJob,job_id)
    try:
        media=project.media[-1]
        set_job(db,job,"running","transcribing",20)
        import asyncio
        stt=asyncio.run(SpeechToTextService().transcribe(media.path))
        req_ids=[r.id for r in db.query(Requirement).filter_by(project_id=project_id).all()]
        if req_ids: db.query(RequirementSource).filter(RequirementSource.requirement_id.in_(req_ids)).delete(synchronize_session=False)
        db.query(Requirement).filter_by(project_id=project_id).delete(synchronize_session=False)
        db.query(Task).filter_by(project_id=project_id).delete()
        db.query(Question).filter_by(project_id=project_id).delete()
        db.query(Contradiction).filter_by(project_id=project_id).delete()
        db.query(ProjectRole).filter_by(project_id=project_id).delete()
        db.query(TranscriptionSegment).filter_by(project_id=project_id).delete()
        segments=[]
        for s in stt["segments"]:
            seg=TranscriptionSegment(project_id=project_id,external_id=s["id"],start_time=s["start"],end_time=s["end"],text=s["text"],speaker=s.get("speaker")); db.add(seg); segments.append(seg)
        db.commit()
        set_job(db,job,"running","analyzing",55)
        analysis=asyncio.run(AIAnalysisService().analyze(stt["segments"]))
        for r in analysis.get("requirements",[]):
            source_ids=r.get("source_segment_ids",[]); source_segs=[s for s in segments if s.external_id in source_ids]
            start=min([s.start_time for s in source_segs],default=r.get("start_time")); end=max([s.end_time for s in source_segs],default=r.get("end_time"))
            req=Requirement(project_id=project_id,code=r.get("id") or f"REQ-{len(project.requirements)+1:03d}",title=r.get("title","Без названия"),description=r.get("description", ""),type=r.get("type","functional"),priority=r.get("priority","medium"),role=r.get("role",""),status=r.get("status","open"),source_text=r.get("source_text", ""),start_time=start,end_time=end,confidence=r.get("confidence",0.0),needs_clarification=r.get("needs_clarification",False),priority_reason=r.get("priority_reason", "")); db.add(req); db.flush()
            for sid in source_ids:
                seg=next((s for s in segments if s.external_id==sid),None)
                if seg: db.add(RequirementSource(requirement_id=req.id,segment_id=seg.id))
        for t in analysis.get("tasks",[]): db.add(Task(project_id=project_id,title=t if isinstance(t,str) else t.get("title","Задача"),description="" if isinstance(t,str) else t.get("description", "")))
        for role in analysis.get("roles",[]): db.add(ProjectRole(project_id=project_id,name=role if isinstance(role,str) else role.get("name","Роль")))
        for q in analysis.get("questions",[]): db.add(Question(project_id=project_id,text=q if isinstance(q,str) else q.get("text",""),source_text="" if isinstance(q,str) else q.get("source_text",""),start_time=None,end_time=None))
        for c in analysis.get("contradictions",[]): db.add(Contradiction(project_id=project_id,title=c if isinstance(c,str) else c.get("title","Противоречие"),description="" if isinstance(c,str) else c.get("description",""),severity="high" if isinstance(c,str) else c.get("severity","high"),source_text="" if isinstance(c,str) else c.get("source_text","")))
        db.commit()
        set_job(db,job,"running","generating_tz",85)
        if project.spec: db.delete(project.spec); db.flush()
        spec=TechnicalSpecification(project_id=project_id,content_json=json.dumps(analysis,ensure_ascii=False)); db.add(spec); db.flush()
        db.add(TechnicalSpecificationVersion(project_id=project_id,version_number=1,content_json=json.dumps(analysis,ensure_ascii=False),reason="Создано AI"))
        project.status="completed"; db.add(ChangeHistory(project_id=project_id,action="AI_ANALYSIS_COMPLETED",entity_type="project",entity_id=project_id,details="Создано AI"))
        db.commit(); set_job(db,job,"completed","completed",100)
    except Exception as exc:
        db.rollback(); job=db.get(AIProcessingJob,job_id); set_job(db,job,"failed","failed",0,str(exc))
    finally:
        db.close()
