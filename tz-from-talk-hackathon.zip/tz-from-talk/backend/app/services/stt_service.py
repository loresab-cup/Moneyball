from pathlib import Path
import httpx
from app.core.config import settings
from app.services.demo_service import load_demo

class SpeechToTextService:
    async def transcribe(self, file_path: str):
        if settings.demo_mode or not settings.stt_api_key:
            return load_demo()
        headers = {"Authorization": f"Bearer {settings.stt_api_key}"}
        data = {"model": settings.stt_model, "response_format": "verbose_json"}
        async with httpx.AsyncClient(timeout=300) as client:
            with open(file_path, "rb") as f:
                response = await client.post(settings.stt_api_url, headers=headers, data=data, files={"file": (Path(file_path).name, f)})
            response.raise_for_status()
            payload = response.json()
        segments = payload.get("segments", [])
        return {"segments": [{"id": i+1, "start": s.get("start",0), "end": s.get("end",0), "text": s.get("text","").strip(), "speaker": s.get("speaker")} for i,s in enumerate(segments)]}
