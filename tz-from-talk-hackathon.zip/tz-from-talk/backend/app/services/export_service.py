import io, json
from reportlab.lib.pagesizes import A4
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer
from reportlab.lib.styles import getSampleStyleSheet
from docx import Document

def to_markdown(spec):
    p=spec.get("project",{})
    lines=[f"# {p.get('title','Техническое задание')}","",p.get("description","")]
    for label,key in [("Цель","goal"),("Актуальность","relevance"),("Проблема","problem")]: lines += [f"## {label}",p.get(key) or "Информация не была обнаружена в исходном разговоре.",""]
    lines += ["## Функциональные требования"]
    for r in spec.get("requirements",[]): lines += [f"### {r.get('id',r.get('code','REQ'))} — {r.get('title','')}",r.get('description',''),f"- Приоритет: {r.get('priority','medium')}",f"- Роль: {r.get('role','')}",""]
    for label,key in [("Задачи","tasks"),("Ограничения","constraints"),("Договорённости","agreements"),("Противоречия","contradictions"),("Открытые вопросы","questions"),("User Stories","user_stories")]:
        lines += [f"## {label}"]
        for item in spec.get(key,[]): lines.append(f"- {item if isinstance(item,str) else item.get('text') or item.get('title') or item}")
        lines.append("")
    return "\n".join(lines)

def to_pdf(spec):
    buf=io.BytesIO(); doc=SimpleDocTemplate(buf,pagesize=A4,rightMargin=40,leftMargin=40,topMargin=40,bottomMargin=40); styles=getSampleStyleSheet(); story=[]
    for line in to_markdown(spec).splitlines():
        if line.startswith('# '): story.append(Paragraph(line[2:],styles['Title']))
        elif line.startswith('## '): story.append(Paragraph(line[3:],styles['Heading2']))
        elif line.startswith('### '): story.append(Paragraph(line[4:],styles['Heading3']))
        elif line: story.append(Paragraph(line.replace('&','&amp;'),styles['BodyText']))
        story.append(Spacer(1,6))
    doc.build(story); buf.seek(0); return buf

def to_docx(spec):
    d=Document();
    for line in to_markdown(spec).splitlines():
        if line.startswith('# '): d.add_heading(line[2:],0)
        elif line.startswith('## '): d.add_heading(line[3:],1)
        elif line.startswith('### '): d.add_heading(line[4:],2)
        elif line: d.add_paragraph(line)
    buf=io.BytesIO(); d.save(buf); buf.seek(0); return buf
