from pathlib import Path
import json

BASE = Path(__file__).resolve().parents[3] / "demo"

def load_demo():
    return json.loads((BASE / "transcription.json").read_text(encoding="utf-8"))
