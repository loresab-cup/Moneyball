import json, httpx
from app.core.config import settings
from app.services.demo_service import load_demo

SYSTEM_PROMPT = '''Ты — аналитик требований. Проанализируй расшифровку встречи заказчика и технического специалиста. Не придумывай факты. Извлекай только то, что подтверждается текстом. Если данных недостаточно, отмечай needs_clarification=true и создавай вопрос. Для каждого требования обязательно указывай source_segment_ids, source_text, start_time и end_time. Приоритет обоснуй. Confidence рассчитывай прозрачно: базово 0.95 за однозначное требование с прямым источником, снижай за неполный контекст, неоднозначность и конфликт. Верни только JSON следующей формы: project{title,description,goal,relevance,problem}, tasks[], requirements[], user_stories[], roles[], constraints[], agreements[], contradictions[], questions[], clarifications[].'''

def normalize(data):
    data.setdefault("project", {})
    for key in ["tasks","requirements","user_stories","roles","constraints","agreements","contradictions","questions","clarifications"]: data.setdefault(key, [])
    return data

class AIAnalysisService:
    async def analyze(self, segments):
        if settings.demo_mode or not settings.llm_api_key:
            return normalize(load_demo()["analysis"])
        transcript = "\n".join(f"[{s['id']}] {s['start']:.2f}-{s['end']:.2f}: {s['text']}" for s in segments)
        body = {"model": settings.llm_model, "temperature": 0.1, "response_format": {"type":"json_object"}, "messages":[{"role":"system","content":SYSTEM_PROMPT},{"role":"user","content":transcript}]}
        headers={"Authorization":f"Bearer {settings.llm_api_key}","Content-Type":"application/json"}
        async with httpx.AsyncClient(timeout=300) as client:
            r=await client.post(settings.llm_api_url, headers=headers, json=body); r.raise_for_status(); payload=r.json()
        return normalize(json.loads(payload["choices"][0]["message"]["content"]))
