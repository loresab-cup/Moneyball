from pathlib import Path
import json, uuid
from fastapi import APIRouter, Depends, HTTPException, UploadFile, File, BackgroundTasks
from fastapi.responses import StreamingResponse, PlainTextResponse, FileResponse
from sqlalchemy.orm import Session
from app.core.db import get_db
from app.core.security import hash_password, verify_password, create_access_token
from app.models import *
from app.schemas.schemas import *
from app.api.deps import current_user, owned_project
from app.workers.pipeline import run_pipeline
from app.services.export_service import to_markdown,to_pdf,to_docx
from app.core.config import settings

router=APIRouter(prefix="/api")
UPLOADS=Path(__file__).resolve().parents[3]/"uploads"; UPLOADS.mkdir(exist_ok=True)

@router.post('/auth/register',response_model=AuthOut)
def register(data:AuthIn,db:Session=Depends(get_db)):
    if db.query(User).filter_by(email=data.email).first(): raise HTTPException(409,"Email уже зарегистрирован")
    u=User(email=data.email,password_hash=hash_password(data.password)); db.add(u); db.commit(); db.refresh(u); return AuthOut(access_token=create_access_token(u.id))
@router.post('/auth/login',response_model=AuthOut)
def login(data:AuthIn,db:Session=Depends(get_db)):
    u=db.query(User).filter_by(email=data.email).first()
    if not u or not verify_password(data.password,u.password_hash): raise HTTPException(401,"Неверный email или пароль")
    return AuthOut(access_token=create_access_token(u.id))
@router.post('/auth/logout')
def logout(): return {"ok":True}

@router.get('/projects')
def projects(user=Depends(current_user),db:Session=Depends(get_db)):
    out=[]
    for p in db.query(Project).filter_by(owner_id=user.id).order_by(Project.updated_at.desc()).all(): out.append({"id":p.id,"title":p.title,"description":p.description,"status":p.status,"created_at":p.created_at.isoformat(),"updated_at":p.updated_at.isoformat(),"requirements":len(p.requirements),"questions":len(p.questions),"contradictions":len(p.contradictions)})
    return out
@router.post('/projects',response_model=ProjectOut)
def create_project(data:ProjectCreate,user=Depends(current_user),db:Session=Depends(get_db)):
    p=Project(owner_id=user.id,title=data.title,description=data.description); db.add(p); db.commit(); db.refresh(p); return p
@router.get('/projects/{pid}')
def project_detail(pid:int,user=Depends(current_user),db:Session=Depends(get_db)):
    p=owned_project(pid,user,db)
    spec=json.loads(p.spec.content_json) if p.spec else {}
    return {"id":p.id,"title":p.title,"description":p.description,"status":p.status,"created_at":p.created_at.isoformat(),"updated_at":p.updated_at.isoformat(),"requirements":[RequirementOut.model_validate(r).model_dump() for r in p.requirements],"segments":[SegmentOut.model_validate(s).model_dump() for s in p.segments],"tasks":[{"id":t.id,"title":t.title,"description":t.description} for t in p.tasks],"questions":[{"id":q.id,"text":q.text,"source_text":q.source_text,"start_time":q.start_time,"end_time":q.end_time,"status":q.status} for q in p.questions],"contradictions":[{"id":c.id,"title":c.title,"description":c.description,"severity":c.severity,"status":c.status} for c in p.contradictions],"roles":[r.name for r in p.roles],"spec":spec}
@router.patch('/projects/{pid}',response_model=ProjectOut)
def patch_project(pid:int,data:ProjectPatch,user=Depends(current_user),db:Session=Depends(get_db)):
    p=owned_project(pid,user,db)
    if data.title is not None:p.title=data.title
    if data.description is not None:p.description=data.description
    db.add(ChangeHistory(project_id=pid,actor_id=user.id,action="PROJECT_UPDATED",entity_type="project",entity_id=pid)); db.commit(); db.refresh(p); return p
@router.delete('/projects/{pid}')
def delete_project(pid:int,user=Depends(current_user),db:Session=Depends(get_db)):
    p=owned_project(pid,user,db); db.delete(p); db.commit(); return {"ok":True}

@router.post('/projects/{pid}/media')
async def upload(pid:int,file:UploadFile=File(...),user=Depends(current_user),db:Session=Depends(get_db)):
    p=owned_project(pid,user,db); allowed={'audio/mpeg','audio/wav','audio/x-wav','audio/mp4','audio/webm','video/mp4','video/webm','video/quicktime','audio/ogg'}
    if file.content_type not in allowed: raise HTTPException(415,"Неподдерживаемый формат")
    content=await file.read()
    if len(content)>settings.max_upload_mb*1024*1024: raise HTTPException(413,"Файл слишком большой")
    safe=f"{uuid.uuid4().hex}_{Path(file.filename or 'recording').name}"; path=UPLOADS/safe; path.write_bytes(content)
    db.add(MediaFile(project_id=pid,filename=file.filename or safe,path=str(path),mime_type=file.content_type or 'application/octet-stream',size_bytes=len(content))); p.status='uploaded'; db.commit(); return {"filename":file.filename,"size":len(content)}

@router.get('/projects/{pid}/media')
def media(pid:int,user=Depends(current_user),db:Session=Depends(get_db)):
    p=owned_project(pid,user,db)
    if not p.media: raise HTTPException(404,"Медиафайл не найден")
    m=p.media[-1]
    return FileResponse(m.path, media_type=m.mime_type, filename=m.filename)

@router.post('/projects/{pid}/process',response_model=JobOut)
def process(pid:int,background:BackgroundTasks,user=Depends(current_user),db:Session=Depends(get_db)):
    p=owned_project(pid,user,db)
    if not p.media: raise HTTPException(400,"Сначала загрузите запись")
    job=AIProcessingJob(project_id=pid,status='queued',step='queued',progress=0); db.add(job); p.status='processing'; db.commit(); db.refresh(job)
    background.add_task(run_pipeline,pid,job.id)
    return job
@router.get('/projects/{pid}/jobs/latest',response_model=JobOut)
def latest_job(pid:int,user=Depends(current_user),db:Session=Depends(get_db)):
    p=owned_project(pid,user,db); j=db.query(AIProcessingJob).filter_by(project_id=p.id).order_by(AIProcessingJob.id.desc()).first()
    if not j: raise HTTPException(404,"Задач обработки нет")
    return j
@router.get('/projects/{pid}/transcription')
def transcription(pid:int,user=Depends(current_user),db:Session=Depends(get_db)):
    p=owned_project(pid,user,db); return [SegmentOut.model_validate(s).model_dump() for s in p.segments]
@router.get('/projects/{pid}/requirements')
def requirements(pid:int,user=Depends(current_user),db:Session=Depends(get_db)):
    p=owned_project(pid,user,db); return [RequirementOut.model_validate(r).model_dump() for r in p.requirements]
@router.patch('/requirements/{rid}')
def patch_requirement(rid:int,data:RequirementPatch,user=Depends(current_user),db:Session=Depends(get_db)):
    r=db.get(Requirement,rid)
    if not r: raise HTTPException(404,"Требование не найдено")
    owned_project(r.project_id,user,db)
    for k,v in data.model_dump(exclude_none=True).items(): setattr(r,k,v)
    db.add(ChangeHistory(project_id=r.project_id,actor_id=user.id,action='REQUIREMENT_UPDATED',entity_type='requirement',entity_id=rid,details=json.dumps(data.model_dump(exclude_none=True),ensure_ascii=False))); db.commit(); return RequirementOut.model_validate(r)
@router.delete('/requirements/{rid}')
def delete_requirement(rid:int,user=Depends(current_user),db:Session=Depends(get_db)):
    r=db.get(Requirement,rid)
    if not r: raise HTTPException(404,"Требование не найдено")
    owned_project(r.project_id,user,db); pid=r.project_id; db.delete(r); db.add(ChangeHistory(project_id=pid,actor_id=user.id,action='REQUIREMENT_DELETED',entity_type='requirement',entity_id=rid)); db.commit(); return {"ok":True}


@router.post('/projects/{pid}/requirements',response_model=RequirementOut)
def create_requirement(pid:int,user=Depends(current_user),db:Session=Depends(get_db)):
    p=owned_project(pid,user,db)
    n=len(p.requirements)+1
    r=Requirement(project_id=pid,code=f"REQ-{n:03d}",title="Новое требование",description="Описание требования",type="functional",priority="medium",role="",status="open",confidence=1.0)
    db.add(r); db.add(ChangeHistory(project_id=pid,actor_id=user.id,action='REQUIREMENT_CREATED',entity_type='requirement',details='Добавлено пользователем')); db.commit(); db.refresh(r); return r

@router.get('/projects/{pid}/technical-specification')
def get_spec(pid:int,user=Depends(current_user),db:Session=Depends(get_db)):
    p=owned_project(pid,user,db); return json.loads(p.spec.content_json) if p.spec else {}
@router.patch('/projects/{pid}/technical-specification')
def patch_spec(pid:int,data:SpecPatch,user=Depends(current_user),db:Session=Depends(get_db)):
    p=owned_project(pid,user,db); current=json.loads(p.spec.content_json) if p.spec else {}; v=(max([x.version_number for x in p.versions],default=0)+1)
    if not p.spec: p.spec=TechnicalSpecification(project_id=pid,content_json=json.dumps(data.content,ensure_ascii=False))
    else: p.spec.content_json=json.dumps(data.content,ensure_ascii=False)
    db.add(TechnicalSpecificationVersion(project_id=pid,version_number=v,content_json=json.dumps(data.content,ensure_ascii=False),reason='Пользователь изменил ТЗ'))
    db.add(ChangeHistory(project_id=pid,actor_id=user.id,action='SPEC_UPDATED',entity_type='technical_specification',entity_id=p.spec.id if p.spec else None,details='Сохранено пользователем')); db.commit(); return data.content
@router.get('/projects/{pid}/history')
def history(pid:int,user=Depends(current_user),db:Session=Depends(get_db)):
    p=owned_project(pid,user,db); return [{"id":x.id,"action":x.action,"entity_type":x.entity_type,"entity_id":x.entity_id,"details":x.details,"created_at":x.created_at.isoformat()} for x in p.changes]
@router.post('/projects/{pid}/restore/{version}')
def restore(pid:int,version:int,user=Depends(current_user),db:Session=Depends(get_db)):
    p=owned_project(pid,user,db); v=db.query(TechnicalSpecificationVersion).filter_by(project_id=pid,version_number=version).first()
    if not v: raise HTTPException(404,"Версия не найдена")
    if not p.spec:p.spec=TechnicalSpecification(project_id=pid,content_json=v.content_json)
    else:p.spec.content_json=v.content_json
    newv=max([x.version_number for x in p.versions],default=0)+1; db.add(TechnicalSpecificationVersion(project_id=pid,version_number=newv,content_json=v.content_json,reason=f'Восстановлена версия {version}')); db.add(ChangeHistory(project_id=pid,actor_id=user.id,action='SPEC_RESTORED',entity_type='technical_specification',details=f'Восстановлена версия {version}')); db.commit(); return json.loads(v.content_json)
@router.get('/projects/{pid}/export/{fmt}')
def export(pid:int,fmt:str,user=Depends(current_user),db:Session=Depends(get_db)):
    p=owned_project(pid,user,db); spec=json.loads(p.spec.content_json) if p.spec else {}
    if fmt=='md': return PlainTextResponse(to_markdown(spec),media_type='text/markdown',headers={'Content-Disposition':f'attachment; filename="TZ-{pid}.md"'})
    if fmt=='pdf': return StreamingResponse(to_pdf(spec),media_type='application/pdf',headers={'Content-Disposition':f'attachment; filename="TZ-{pid}.pdf"'})
    if fmt=='docx': return StreamingResponse(to_docx(spec),media_type='application/vnd.openxmlformats-officedocument.wordprocessingml.document',headers={'Content-Disposition':f'attachment; filename="TZ-{pid}.docx"'})
    raise HTTPException(400,'Неизвестный формат')
