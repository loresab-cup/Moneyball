from fastapi import Depends, HTTPException, status
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from sqlalchemy.orm import Session
from app.core.db import get_db
from app.core.security import decode_access_token
from app.models import User, Project
security=HTTPBearer(auto_error=False)

def current_user(creds: HTTPAuthorizationCredentials=Depends(security), db:Session=Depends(get_db)):
    if not creds: raise HTTPException(status_code=401,detail="Необходима авторизация")
    try: uid=decode_access_token(creds.credentials)
    except Exception: raise HTTPException(status_code=401,detail="Недействительный токен")
    user=db.get(User,uid)
    if not user: raise HTTPException(status_code=401,detail="Пользователь не найден")
    return user

def owned_project(project_id:int, user:User, db:Session):
    p=db.get(Project,project_id)
    if not p or p.owner_id!=user.id: raise HTTPException(status_code=404,detail="Проект не найден")
    return p
