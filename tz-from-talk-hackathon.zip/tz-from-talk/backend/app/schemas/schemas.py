from pydantic import BaseModel, EmailStr, Field, ConfigDict
from typing import Any
from datetime import datetime

class AuthIn(BaseModel): email: EmailStr; password: str = Field(min_length=6)
class AuthOut(BaseModel): access_token: str; token_type: str = "bearer"
class ProjectCreate(BaseModel): title: str = Field(min_length=1, max_length=255); description: str = ""
class ProjectPatch(BaseModel): title: str | None = None; description: str | None = None
class RequirementPatch(BaseModel):
    title: str | None = None; description: str | None = None; type: str | None = None; role: str | None = None
    priority: str | None = None; status: str | None = None; needs_clarification: bool | None = None; comment: str | None = None
class SpecPatch(BaseModel): content: dict[str, Any]
class ProjectOut(BaseModel): model_config = ConfigDict(from_attributes=True); id:int; title:str; description:str; status:str; created_at:datetime; updated_at:datetime
class RequirementOut(BaseModel): model_config = ConfigDict(from_attributes=True); id:int; code:str; title:str; description:str; type:str; priority:str; role:str; status:str; source_text:str; start_time:float|None; end_time:float|None; confidence:float; needs_clarification:bool; priority_reason:str; comment:str
class SegmentOut(BaseModel): model_config = ConfigDict(from_attributes=True); id:int; start_time:float; end_time:float; text:str; speaker:str|None
class JobOut(BaseModel): model_config = ConfigDict(from_attributes=True); id:int; status:str; step:str; progress:int; error:str
