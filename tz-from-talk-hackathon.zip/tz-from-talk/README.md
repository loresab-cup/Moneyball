# talk→tz — «Из разговора — в ТЗ»

Веб-приложение для превращения записи встречи заказчика и технического специалиста в проверяемое, редактируемое техническое задание.

## Что реализовано
- Регистрация и вход, JWT, изоляция проектов пользователя.
- Проекты и dashboard.
- Загрузка аудио/видео, ограничение MIME/размера.
- Запись с микрофона через MediaRecorder API.
- Абстракция SpeechToTextService.
- Абстракция AIAnalysisService и структурированный JSON.
- Demo Mode без внешних API.
- Асинхронный для HTTP pipeline через FastAPI BackgroundTasks: upload → transcribing → analyzing → generating_tz → completed/failed.
- Транскрипция с таймкодами.
- Требования с source mapping, ролью, приоритетом, confidence и clarification flag.
- Вопросы, противоречия, задачи.
- Аудио-переход к источнику требования.
- Редактирование требований.
- Полное ТЗ в выдвижной панели и JSON editor.
- История изменений и версии ТЗ, восстановление версии через API.
- Экспорт Markdown/PDF/DOCX.
- Responsive UI.
- OpenAPI/Swagger через FastAPI.

## Быстрый запуск

### Docker
```bash
docker compose up --build
```
Открыть http://localhost:5173. API: http://localhost:8000/docs.

### Локально
1. Python 3.12+
2. PostgreSQL 16/17 и Node 22+
3. `cp backend/.env.example backend/.env` и заполнить `DATABASE_URL`.
4. `python -m venv .venv && .venv/Scripts/activate` (Windows) или `source .venv/bin/activate`.
5. `pip install -r backend/requirements.txt`
6. `uvicorn app.main:app --app-dir backend --reload`
7. `cd frontend && npm install && npm run dev`

Для демо оставьте `DEMO_MODE=true`. Реальные STT/LLM ключи можно добавить в `.env`.

## API keys
Ключи хранятся только backend-side: `STT_API_KEY`, `LLM_API_KEY`. Они никогда не передаются frontend.

## AI pipeline
STT возвращает сегменты с `id/start/end/text/speaker`. AI получает транскрипцию с ID сегментов и должен вернуть JSON. Pydantic-схемы и сервисный слой оставлены расширяемыми для другого провайдера.

## Архитектура
- `backend/app/api` — HTTP endpoints и auth dependencies.
- `backend/app/models` — нормализованные SQLAlchemy-модели.
- `backend/app/services` — STT, AI, export.
- `backend/app/workers` — pipeline/background processing.
- `frontend/src` — React/TypeScript UI.
- `demo` — демонстрационная транскрипция и результат анализа.

## Demo сценарий для хакатона
1. Войти/зарегистрироваться.
2. Создать проект.
3. Загрузить любой небольшой аудиофайл или запустить запись микрофона.
4. Дождаться статуса Completed.
5. Открыть требования.
6. Нажать на требование и показать source fragment + таймкод.
7. Показать вопросы/противоречия.
8. Открыть ТЗ, отредактировать и сохранить.
9. Показать историю.
10. Экспортировать PDF/Markdown.

## Дальше
Для production стоит заменить BackgroundTasks на Celery/Redis, добавить object storage, полноценную RBAC-модель, server-side pagination/search и строгие JSON Schema/Pydantic-модели для всего AI-ответа.
